$(function () {
  $('#Ejecutar').click(function (ev) {
    ev.preventDefault();
    $.ajax({
      // async: false,
      type: 'GET',
      url: '/EjecutarProceso',
      // data: evaluacion,
      success: function (result) {
        $.alert({
          type:'green',
          title: 'Correcto',
          content: result
        });
      },
      error: function (er) {
        $.alert({
          type:'red',
          title: 'Error',
          content: 'Error al procesar: ' + er.responseJSON.message
        });
      },
      beforeSend: function () {
        $('#Ejecutar').addClass('active');
        $('#Ejecutar').prop('disabled', true);
      },
      complete: function () {
        $('#Ejecutar').removeClass('active');
        $('#Ejecutar').prop('disabled',false)
      }
    })
  })
})