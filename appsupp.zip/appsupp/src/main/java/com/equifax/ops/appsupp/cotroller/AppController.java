package com.equifax.ops.appsupp.cotroller;

import com.equifax.ops.appsupp.model.Pendinte6Lineas;
import com.equifax.ops.appsupp.repository.Pendiente6LineasRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.StoredProcedureQuery;
import javax.websocket.server.PathParam;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/")
public class AppController {
  @Autowired
  private Pendiente6LineasRepository pendiente6LineasRepository;

  @RequestMapping(value = "/")
  public String Home() {
    return "home";
  }

  @RequestMapping(value = "/EjecutarProceso", method = RequestMethod.GET)
  @ResponseBody
  public String ejecutarProceso() {
    pendiente6LineasRepository.buscaAlertas();
    return "OK procesado correctamente";
  }

  public void readExcel(String fileLocation) throws IOException {
    FileInputStream file = new FileInputStream(new File(fileLocation));
    Workbook workbook = new XSSFWorkbook(file);
    Sheet sheet = workbook.getSheetAt(0);

    Pendinte6Lineas registro = null;
    for (Row row : sheet) {
      registro = new Pendinte6Lineas();
      for (Cell cell : row) {
        switch (cell.getColumnIndex()) {
          case 0:
            registro.setNumeroLiquidacion(cell.getStringCellValue());
            break;
          case 1:
            registro.setFechaLiquidacion(cell.getStringCellValue());
            break;
          case 2:
            registro.setAnexo(cell.getStringCellValue());
            break;
          case 3:
            registro.setNumTel(cell.getStringCellValue());
            break;
          case 4:
            registro.setTipoDocumento(cell.getStringCellValue());
            break;
          case 5:
            registro.setNroDocumento(cell.getStringCellValue());
            break;
          case 6:
            registro.setNombreCliente(cell.getStringCellValue());
            break;
          case 7:
            registro.setFecVta(cell.getStringCellValue());
            break;
          case 8:
            registro.setCodCan(cell.getStringCellValue());
            break;
          case 9:
            registro.setCodEnt(cell.getStringCellValue());
            break;
          case 10:
            registro.setPtoVenta(cell.getStringCellValue());
            break;
          case 11:
            registro.setEntidad(cell.getStringCellValue());
            break;
          case 12:
            registro.setProducto(cell.getStringCellValue());
            break;
          case 13:
            registro.setCodCampana(cell.getStringCellValue());
            break;
          case 14:
            registro.setCampana(cell.getStringCellValue());
            break;
          case 15:
            registro.setPlanexp(cell.getStringCellValue());
            break;
          case 16:
            registro.setDescripcionPlan(cell.getStringCellValue());
            break;
          case 17:
            registro.setNumEsn(cell.getStringCellValue());
            break;
          case 18:
            registro.setEstado(cell.getStringCellValue());
            break;
          case 19:
            registro.setFecEvaluacion(cell.getStringCellValue());
            break;
          case 20:
            registro.setFecRecep(cell.getStringCellValue());
            break;
          case 21:
            registro.setFecRecepFisico(cell.getStringCellValue());
            break;
          case 22:
            registro.setLocalidad(cell.getStringCellValue());
            break;
          case 23:
            registro.setSublocalidad(cell.getStringCellValue());
            break;
          case 24:
            registro.setDescripcionPuntoVta(cell.getStringCellValue());
            break;
          case 25:
            registro.setComision(cell.getStringCellValue());
            break;
          case 26:
            registro.setMonedaAlta(cell.getStringCellValue());
            break;
          case 27:
            registro.setPrecioVenta(cell.getStringCellValue());
            break;
          case 28:
            registro.setPorcentajeAutoliq(cell.getStringCellValue());
            break;
          case 29:
            registro.setMonedaLiquid(cell.getStringCellValue());
            break;
          case 30:
            registro.setMontoDepositar(cell.getStringCellValue());
            break;
          case 31:
            registro.setTipoVenta(cell.getStringCellValue());
            break;
          case 32:
            registro.setEstadoLiquidacion(cell.getStringCellValue());
            break;
          case 33:
            registro.setFechaPago(cell.getStringCellValue());
            break;
          case 34:
            registro.setCodModeloEquipo(cell.getStringCellValue());
            break;
          case 35:
            registro.setModeloEquipo(cell.getStringCellValue());
            break;
          case 36:
            registro.setSimCard(cell.getStringCellValue());
            break;
          case 37:
            registro.setVencimiento(cell.getStringCellValue());
            break;
          case 38:
            registro.setBodega(cell.getStringCellValue());
            break;
          case 39:
            registro.setTipCmb(cell.getStringCellValue());
            break;
          case 40:
            registro.setMtoDscto(cell.getStringCellValue());
            break;
          case 41:
            registro.setFlgVtactdo(cell.getStringCellValue());
            break;
          case 42:
            registro.setDescBaja(cell.getStringCellValue());
            break;
          case 43:
            registro.setTipo(cell.getStringCellValue());
            break;
          case 44:
            registro.setEntorno(cell.getStringCellValue());
            break;
        }
        pendiente6LineasRepository.save(registro);
      }
    }
    if (workbook != null) {
      workbook.close();
    }
  }
}
