package com.equifax.ops.appsupp.model;

import javax.persistence.*;

@Entity
@NamedStoredProcedureQueries({
    @NamedStoredProcedureQuery(
        name = "buscaAlertas",
        procedureName = "BuscaAlertas",
        resultClasses = { Pendinte6Lineas.class }
//        parameters = {
//            @StoredProcedureParameter(name = "p_year", type = Integer.class, mode = ParameterMode.IN),
//            @StoredProcedureParameter(name = "p_year", type = Integer.class, mode = ParameterMode.IN)
//        }
    )
})
public class Pendinte6Lineas {
  private long idRegistro;
  private String numeroLiquidacion;
  private String fechaLiquidacion;
  private String anexo;
  private String numTel;
  private String tipoDocumento;
  private String nroDocumento;
  private String nombreCliente;
  private String fecVta;
  private String codCan;
  private String codEnt;
  private String ptoVenta;
  private String entidad;
  private String producto;
  private String codCampana;
  private String campana;
  private String planexp;
  private String descripcionPlan;
  private String numEsn;
  private String estado;
  private String fecEvaluacion;
  private String fecRecep;
  private String fecRecepFisico;
  private String localidad;
  private String sublocalidad;
  private String descripcionPuntoVta;
  private String comision;
  private String monedaAlta;
  private String precioVenta;
  private String porcentajeAutoliq;
  private String monedaLiquid;
  private String montoDepositar;
  private String tipoVenta;
  private String estadoLiquidacion;
  private String fechaPago;
  private String codModeloEquipo;
  private String modeloEquipo;
  private String simCard;
  private String vencimiento;
  private String bodega;
  private String tipCmb;
  private String mtoDscto;
  private String flgVtactdo;
  private String descBaja;
  private String tipo;
  private String entorno;

  @Id
  @Column(name = "id_registro")
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  public long getIdRegistro() {
    return idRegistro;
  }

  public void setIdRegistro(long idRegistro) {
    this.idRegistro = idRegistro;
  }

  @Basic
  @Column(name = "numero_liquidacion")
  public String getNumeroLiquidacion() {
    return numeroLiquidacion;
  }

  public void setNumeroLiquidacion(String numeroLiquidacion) {
    this.numeroLiquidacion = numeroLiquidacion;
  }

  @Basic
  @Column(name = "fecha_liquidacion")
  public String getFechaLiquidacion() {
    return fechaLiquidacion;
  }

  public void setFechaLiquidacion(String fechaLiquidacion) {
    this.fechaLiquidacion = fechaLiquidacion;
  }

  @Basic
  @Column(name = "anexo")
  public String getAnexo() {
    return anexo;
  }

  public void setAnexo(String anexo) {
    this.anexo = anexo;
  }

  @Basic
  @Column(name = "num_tel")
  public String getNumTel() {
    return numTel;
  }

  public void setNumTel(String numTel) {
    this.numTel = numTel;
  }

  @Basic
  @Column(name = "tipo_documento")
  public String getTipoDocumento() {
    return tipoDocumento;
  }

  public void setTipoDocumento(String tipoDocumento) {
    this.tipoDocumento = tipoDocumento;
  }

  @Basic
  @Column(name = "nro_documento")
  public String getNroDocumento() {
    return nroDocumento;
  }

  public void setNroDocumento(String nroDocumento) {
    this.nroDocumento = nroDocumento;
  }

  @Basic
  @Column(name = "nombre_cliente")
  public String getNombreCliente() {
    return nombreCliente;
  }

  public void setNombreCliente(String nombreCliente) {
    this.nombreCliente = nombreCliente;
  }

  @Basic
  @Column(name = "fec_vta")
  public String getFecVta() {
    return fecVta;
  }

  public void setFecVta(String fecVta) {
    this.fecVta = fecVta;
  }

  @Basic
  @Column(name = "cod_can")
  public String getCodCan() {
    return codCan;
  }

  public void setCodCan(String codCan) {
    this.codCan = codCan;
  }

  @Basic
  @Column(name = "cod_ent")
  public String getCodEnt() {
    return codEnt;
  }

  public void setCodEnt(String codEnt) {
    this.codEnt = codEnt;
  }

  @Basic
  @Column(name = "pto_venta")
  public String getPtoVenta() {
    return ptoVenta;
  }

  public void setPtoVenta(String ptoVenta) {
    this.ptoVenta = ptoVenta;
  }

  @Basic
  @Column(name = "entidad")
  public String getEntidad() {
    return entidad;
  }

  public void setEntidad(String entidad) {
    this.entidad = entidad;
  }

  @Basic
  @Column(name = "producto")
  public String getProducto() {
    return producto;
  }

  public void setProducto(String producto) {
    this.producto = producto;
  }

  @Basic
  @Column(name = "cod_campana")
  public String getCodCampana() {
    return codCampana;
  }

  public void setCodCampana(String codCampana) {
    this.codCampana = codCampana;
  }

  @Basic
  @Column(name = "campana")
  public String getCampana() {
    return campana;
  }

  public void setCampana(String campana) {
    this.campana = campana;
  }

  @Basic
  @Column(name = "planexp")
  public String getPlanexp() {
    return planexp;
  }

  public void setPlanexp(String planexp) {
    this.planexp = planexp;
  }

  @Basic
  @Column(name = "descripcion_plan")
  public String getDescripcionPlan() {
    return descripcionPlan;
  }

  public void setDescripcionPlan(String descripcionPlan) {
    this.descripcionPlan = descripcionPlan;
  }

  @Basic
  @Column(name = "num_esn")
  public String getNumEsn() {
    return numEsn;
  }

  public void setNumEsn(String numEsn) {
    this.numEsn = numEsn;
  }

  @Basic
  @Column(name = "estado")
  public String getEstado() {
    return estado;
  }

  public void setEstado(String estado) {
    this.estado = estado;
  }

  @Basic
  @Column(name = "fec_evaluacion")
  public String getFecEvaluacion() {
    return fecEvaluacion;
  }

  public void setFecEvaluacion(String fecEvaluacion) {
    this.fecEvaluacion = fecEvaluacion;
  }

  @Basic
  @Column(name = "fec_recep")
  public String getFecRecep() {
    return fecRecep;
  }

  public void setFecRecep(String fecRecep) {
    this.fecRecep = fecRecep;
  }

  @Basic
  @Column(name = "fec_recep_fisico")
  public String getFecRecepFisico() {
    return fecRecepFisico;
  }

  public void setFecRecepFisico(String fecRecepFisico) {
    this.fecRecepFisico = fecRecepFisico;
  }

  @Basic
  @Column(name = "localidad")
  public String getLocalidad() {
    return localidad;
  }

  public void setLocalidad(String localidad) {
    this.localidad = localidad;
  }

  @Basic
  @Column(name = "sublocalidad")
  public String getSublocalidad() {
    return sublocalidad;
  }

  public void setSublocalidad(String sublocalidad) {
    this.sublocalidad = sublocalidad;
  }

  @Basic
  @Column(name = "descripcion_punto_vta")
  public String getDescripcionPuntoVta() {
    return descripcionPuntoVta;
  }

  public void setDescripcionPuntoVta(String descripcionPuntoVta) {
    this.descripcionPuntoVta = descripcionPuntoVta;
  }

  @Basic
  @Column(name = "comision")
  public String getComision() {
    return comision;
  }

  public void setComision(String comision) {
    this.comision = comision;
  }

  @Basic
  @Column(name = "moneda_alta")
  public String getMonedaAlta() {
    return monedaAlta;
  }

  public void setMonedaAlta(String monedaAlta) {
    this.monedaAlta = monedaAlta;
  }

  @Basic
  @Column(name = "precio_venta")
  public String getPrecioVenta() {
    return precioVenta;
  }

  public void setPrecioVenta(String precioVenta) {
    this.precioVenta = precioVenta;
  }

  @Basic
  @Column(name = "porcentaje_autoliq")
  public String getPorcentajeAutoliq() {
    return porcentajeAutoliq;
  }

  public void setPorcentajeAutoliq(String porcentajeAutoliq) {
    this.porcentajeAutoliq = porcentajeAutoliq;
  }

  @Basic
  @Column(name = "moneda_liquid")
  public String getMonedaLiquid() {
    return monedaLiquid;
  }

  public void setMonedaLiquid(String monedaLiquid) {
    this.monedaLiquid = monedaLiquid;
  }

  @Basic
  @Column(name = "monto_depositar")
  public String getMontoDepositar() {
    return montoDepositar;
  }

  public void setMontoDepositar(String montoDepositar) {
    this.montoDepositar = montoDepositar;
  }

  @Basic
  @Column(name = "tipo_venta")
  public String getTipoVenta() {
    return tipoVenta;
  }

  public void setTipoVenta(String tipoVenta) {
    this.tipoVenta = tipoVenta;
  }

  @Basic
  @Column(name = "estado_liquidacion")
  public String getEstadoLiquidacion() {
    return estadoLiquidacion;
  }

  public void setEstadoLiquidacion(String estadoLiquidacion) {
    this.estadoLiquidacion = estadoLiquidacion;
  }

  @Basic
  @Column(name = "fecha_pago")
  public String getFechaPago() {
    return fechaPago;
  }

  public void setFechaPago(String fechaPago) {
    this.fechaPago = fechaPago;
  }

  @Basic
  @Column(name = "cod_modelo_equipo")
  public String getCodModeloEquipo() {
    return codModeloEquipo;
  }

  public void setCodModeloEquipo(String codModeloEquipo) {
    this.codModeloEquipo = codModeloEquipo;
  }

  @Basic
  @Column(name = "modelo_equipo")
  public String getModeloEquipo() {
    return modeloEquipo;
  }

  public void setModeloEquipo(String modeloEquipo) {
    this.modeloEquipo = modeloEquipo;
  }

  @Basic
  @Column(name = "sim_card")
  public String getSimCard() {
    return simCard;
  }

  public void setSimCard(String simCard) {
    this.simCard = simCard;
  }

  @Basic
  @Column(name = "vencimiento")
  public String getVencimiento() {
    return vencimiento;
  }

  public void setVencimiento(String vencimiento) {
    this.vencimiento = vencimiento;
  }

  @Basic
  @Column(name = "bodega")
  public String getBodega() {
    return bodega;
  }

  public void setBodega(String bodega) {
    this.bodega = bodega;
  }

  @Basic
  @Column(name = "tip_cmb")
  public String getTipCmb() {
    return tipCmb;
  }

  public void setTipCmb(String tipCmb) {
    this.tipCmb = tipCmb;
  }

  @Basic
  @Column(name = "mto_dscto")
  public String getMtoDscto() {
    return mtoDscto;
  }

  public void setMtoDscto(String mtoDscto) {
    this.mtoDscto = mtoDscto;
  }

  @Basic
  @Column(name = "flg_vtactdo")
  public String getFlgVtactdo() {
    return flgVtactdo;
  }

  public void setFlgVtactdo(String flgVtactdo) {
    this.flgVtactdo = flgVtactdo;
  }

  @Basic
  @Column(name = "desc_baja")
  public String getDescBaja() {
    return descBaja;
  }

  public void setDescBaja(String descBaja) {
    this.descBaja = descBaja;
  }

  @Basic
  @Column(name = "tipo")
  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  @Basic
  @Column(name = "entorno")
  public String getEntorno() {
    return entorno;
  }

  public void setEntorno(String entorno) {
    this.entorno = entorno;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    Pendinte6Lineas that = (Pendinte6Lineas) o;

    if (idRegistro != that.idRegistro) return false;
    if (numeroLiquidacion != null ? !numeroLiquidacion.equals(that.numeroLiquidacion) : that.numeroLiquidacion != null) return false;
    if (fechaLiquidacion != null ? !fechaLiquidacion.equals(that.fechaLiquidacion) : that.fechaLiquidacion != null) return false;
    if (anexo != null ? !anexo.equals(that.anexo) : that.anexo != null) return false;
    if (numTel != null ? !numTel.equals(that.numTel) : that.numTel != null) return false;
    if (tipoDocumento != null ? !tipoDocumento.equals(that.tipoDocumento) : that.tipoDocumento != null) return false;
    if (nroDocumento != null ? !nroDocumento.equals(that.nroDocumento) : that.nroDocumento != null) return false;
    if (nombreCliente != null ? !nombreCliente.equals(that.nombreCliente) : that.nombreCliente != null) return false;
    if (fecVta != null ? !fecVta.equals(that.fecVta) : that.fecVta != null) return false;
    if (codCan != null ? !codCan.equals(that.codCan) : that.codCan != null) return false;
    if (codEnt != null ? !codEnt.equals(that.codEnt) : that.codEnt != null) return false;
    if (ptoVenta != null ? !ptoVenta.equals(that.ptoVenta) : that.ptoVenta != null) return false;
    if (entidad != null ? !entidad.equals(that.entidad) : that.entidad != null) return false;
    if (producto != null ? !producto.equals(that.producto) : that.producto != null) return false;
    if (codCampana != null ? !codCampana.equals(that.codCampana) : that.codCampana != null) return false;
    if (campana != null ? !campana.equals(that.campana) : that.campana != null) return false;
    if (planexp != null ? !planexp.equals(that.planexp) : that.planexp != null) return false;
    if (descripcionPlan != null ? !descripcionPlan.equals(that.descripcionPlan) : that.descripcionPlan != null) return false;
    if (numEsn != null ? !numEsn.equals(that.numEsn) : that.numEsn != null) return false;
    if (estado != null ? !estado.equals(that.estado) : that.estado != null) return false;
    if (fecEvaluacion != null ? !fecEvaluacion.equals(that.fecEvaluacion) : that.fecEvaluacion != null) return false;
    if (fecRecep != null ? !fecRecep.equals(that.fecRecep) : that.fecRecep != null) return false;
    if (fecRecepFisico != null ? !fecRecepFisico.equals(that.fecRecepFisico) : that.fecRecepFisico != null) return false;
    if (localidad != null ? !localidad.equals(that.localidad) : that.localidad != null) return false;
    if (sublocalidad != null ? !sublocalidad.equals(that.sublocalidad) : that.sublocalidad != null) return false;
    if (descripcionPuntoVta != null ? !descripcionPuntoVta.equals(that.descripcionPuntoVta) : that.descripcionPuntoVta != null) return false;
    if (comision != null ? !comision.equals(that.comision) : that.comision != null) return false;
    if (monedaAlta != null ? !monedaAlta.equals(that.monedaAlta) : that.monedaAlta != null) return false;
    if (precioVenta != null ? !precioVenta.equals(that.precioVenta) : that.precioVenta != null) return false;
    if (porcentajeAutoliq != null ? !porcentajeAutoliq.equals(that.porcentajeAutoliq) : that.porcentajeAutoliq != null) return false;
    if (monedaLiquid != null ? !monedaLiquid.equals(that.monedaLiquid) : that.monedaLiquid != null) return false;
    if (montoDepositar != null ? !montoDepositar.equals(that.montoDepositar) : that.montoDepositar != null) return false;
    if (tipoVenta != null ? !tipoVenta.equals(that.tipoVenta) : that.tipoVenta != null) return false;
    if (estadoLiquidacion != null ? !estadoLiquidacion.equals(that.estadoLiquidacion) : that.estadoLiquidacion != null) return false;
    if (fechaPago != null ? !fechaPago.equals(that.fechaPago) : that.fechaPago != null) return false;
    if (codModeloEquipo != null ? !codModeloEquipo.equals(that.codModeloEquipo) : that.codModeloEquipo != null) return false;
    if (modeloEquipo != null ? !modeloEquipo.equals(that.modeloEquipo) : that.modeloEquipo != null) return false;
    if (simCard != null ? !simCard.equals(that.simCard) : that.simCard != null) return false;
    if (vencimiento != null ? !vencimiento.equals(that.vencimiento) : that.vencimiento != null) return false;
    if (bodega != null ? !bodega.equals(that.bodega) : that.bodega != null) return false;
    if (tipCmb != null ? !tipCmb.equals(that.tipCmb) : that.tipCmb != null) return false;
    if (mtoDscto != null ? !mtoDscto.equals(that.mtoDscto) : that.mtoDscto != null) return false;
    if (flgVtactdo != null ? !flgVtactdo.equals(that.flgVtactdo) : that.flgVtactdo != null) return false;
    if (descBaja != null ? !descBaja.equals(that.descBaja) : that.descBaja != null) return false;
    if (tipo != null ? !tipo.equals(that.tipo) : that.tipo != null) return false;
    if (entorno != null ? !entorno.equals(that.entorno) : that.entorno != null) return false;

    return true;
  }

  @Override
  public int hashCode() {
    int result = (int) (idRegistro ^ (idRegistro >>> 32));
    result = 31 * result + (numeroLiquidacion != null ? numeroLiquidacion.hashCode() : 0);
    result = 31 * result + (fechaLiquidacion != null ? fechaLiquidacion.hashCode() : 0);
    result = 31 * result + (anexo != null ? anexo.hashCode() : 0);
    result = 31 * result + (numTel != null ? numTel.hashCode() : 0);
    result = 31 * result + (tipoDocumento != null ? tipoDocumento.hashCode() : 0);
    result = 31 * result + (nroDocumento != null ? nroDocumento.hashCode() : 0);
    result = 31 * result + (nombreCliente != null ? nombreCliente.hashCode() : 0);
    result = 31 * result + (fecVta != null ? fecVta.hashCode() : 0);
    result = 31 * result + (codCan != null ? codCan.hashCode() : 0);
    result = 31 * result + (codEnt != null ? codEnt.hashCode() : 0);
    result = 31 * result + (ptoVenta != null ? ptoVenta.hashCode() : 0);
    result = 31 * result + (entidad != null ? entidad.hashCode() : 0);
    result = 31 * result + (producto != null ? producto.hashCode() : 0);
    result = 31 * result + (codCampana != null ? codCampana.hashCode() : 0);
    result = 31 * result + (campana != null ? campana.hashCode() : 0);
    result = 31 * result + (planexp != null ? planexp.hashCode() : 0);
    result = 31 * result + (descripcionPlan != null ? descripcionPlan.hashCode() : 0);
    result = 31 * result + (numEsn != null ? numEsn.hashCode() : 0);
    result = 31 * result + (estado != null ? estado.hashCode() : 0);
    result = 31 * result + (fecEvaluacion != null ? fecEvaluacion.hashCode() : 0);
    result = 31 * result + (fecRecep != null ? fecRecep.hashCode() : 0);
    result = 31 * result + (fecRecepFisico != null ? fecRecepFisico.hashCode() : 0);
    result = 31 * result + (localidad != null ? localidad.hashCode() : 0);
    result = 31 * result + (sublocalidad != null ? sublocalidad.hashCode() : 0);
    result = 31 * result + (descripcionPuntoVta != null ? descripcionPuntoVta.hashCode() : 0);
    result = 31 * result + (comision != null ? comision.hashCode() : 0);
    result = 31 * result + (monedaAlta != null ? monedaAlta.hashCode() : 0);
    result = 31 * result + (precioVenta != null ? precioVenta.hashCode() : 0);
    result = 31 * result + (porcentajeAutoliq != null ? porcentajeAutoliq.hashCode() : 0);
    result = 31 * result + (monedaLiquid != null ? monedaLiquid.hashCode() : 0);
    result = 31 * result + (montoDepositar != null ? montoDepositar.hashCode() : 0);
    result = 31 * result + (tipoVenta != null ? tipoVenta.hashCode() : 0);
    result = 31 * result + (estadoLiquidacion != null ? estadoLiquidacion.hashCode() : 0);
    result = 31 * result + (fechaPago != null ? fechaPago.hashCode() : 0);
    result = 31 * result + (codModeloEquipo != null ? codModeloEquipo.hashCode() : 0);
    result = 31 * result + (modeloEquipo != null ? modeloEquipo.hashCode() : 0);
    result = 31 * result + (simCard != null ? simCard.hashCode() : 0);
    result = 31 * result + (vencimiento != null ? vencimiento.hashCode() : 0);
    result = 31 * result + (bodega != null ? bodega.hashCode() : 0);
    result = 31 * result + (tipCmb != null ? tipCmb.hashCode() : 0);
    result = 31 * result + (mtoDscto != null ? mtoDscto.hashCode() : 0);
    result = 31 * result + (flgVtactdo != null ? flgVtactdo.hashCode() : 0);
    result = 31 * result + (descBaja != null ? descBaja.hashCode() : 0);
    result = 31 * result + (tipo != null ? tipo.hashCode() : 0);
    result = 31 * result + (entorno != null ? entorno.hashCode() : 0);
    return result;
  }
}
