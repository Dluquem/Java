package com.equifax.ops.appsupp.repository;

import com.equifax.ops.appsupp.model.Pendinte6Lineas;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;

public interface Pendiente6LineasRepository extends JpaRepository<Pendinte6Lineas,Long> {


  @Procedure(name = "buscaAlertas")
  void buscaAlertas();

}
